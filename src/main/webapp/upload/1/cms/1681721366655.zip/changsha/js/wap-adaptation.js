/*! Date:Thu Aug 02 2018 16:15:18 GMT+0800 (CST), chunkhash:d00cb8d4cb5d814ce348 */
!function(e, t) {
  "object" == typeof exports && "object" == typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define([], t) : "object" == typeof exports ? exports.LibFlexible = t() : e.LibFlexible = t()
}("undefined" != typeof self ? self : this, function() {
  return function(e) {
      var t = {};
      function r(i) {
          if (t[i])
              return t[i].exports;
          var n = t[i] = {
              i: i,
              l: !1,
              exports: {}
          };
          return e[i].call(n.exports, n, n.exports, r),
          n.l = !0,
          n.exports
      }
      return r.m = e,
      r.c = t,
      r.d = function(e, t, i) {
          r.o(e, t) || Object.defineProperty(e, t, {
              configurable: !1,
              enumerable: !0,
              get: i
          })
      }
      ,
      r.n = function(e) {
          var t = e && e.__esModule ? function() {
              return e["default"]
          }
          : function() {
              return e
          }
          ;
          return r.d(t, "a", t),
          t
      }
      ,
      r.o = function(e, t) {
          return Object.prototype.hasOwnProperty.call(e, t)
      }
      ,
      r.p = "/dist/",
      r(r.s = "3177845424933048caec")
  }({
      "3177845424933048caec": function(e, t) {
          !function(e, t) {
              function r() {
                  try {
                      var t = o.getBoundingClientRect().width;
                      t / s > 540 && (t = 540 * s);
                      var r = t / 10;
                      o.style.fontSize = r + "px",
                      p.rem = e.rem = r
                  } catch (i) {
                      throw i.position = "src/index.js 68:76",
                      Error(i)
                  }
              }
              try {
                  var i, n = e.document, o = n.documentElement, a = n.querySelector('meta[name="viewport"]'), c = n.querySelector('meta[name="flexible"]'), s = 0, l = 0, p = t.flexible || (t.flexible = {});
                  if (a) {
                      var d = a.getAttribute("content").match(/initial\-scale=([\d\.]+)/);
                      d && (l = parseFloat(d[1]),
                      s = parseInt(1 / l))
                  } else if (c) {
                      var u = c.getAttribute("content");
                      if (u) {
                          var f = u.match(/initial\-dpr=([\d\.]+)/)
                            , m = u.match(/maximum\-dpr=([\d\.]+)/);
                          f && (s = parseFloat(f[1]),
                          l = parseFloat((1 / s).toFixed(2))),
                          m && (s = parseFloat(m[1]),
                          l = parseFloat((1 / s).toFixed(2)))
                      }
                  }
                  if (!s && !l) {
                      e.navigator.appVersion.match(/android/gi);
                      var h = e.navigator.appVersion.match(/iphone/gi)
                        , x = e.devicePixelRatio;
                      l = 1 / (s = h ? x >= 3 && (!s || s >= 3) ? 3 : x >= 2 && (!s || s >= 2) ? 2 : 1 : 1)
                  }
                  if (o.setAttribute("data-dpr", s),
                  !a)
                      if ((a = n.createElement("meta")).setAttribute("name", "viewport"),
                      a.setAttribute("content", "initial-scale=" + l + ", maximum-scale=" + l + ", minimum-scale=" + l + ", user-scalable=no"),
                      o.firstElementChild)
                          o.firstElementChild.appendChild(a);
                      else {
                          var y = n.createElement("div");
                          y.appendChild(a),
                          n.write(y.innerHTML)
                      }
                  if(document.addEventListener){
                  e.addEventListener("resize", function() {
                      try {
                          clearTimeout(i),
                          i = setTimeout(r, 300)
                      } catch (e) {
                          throw e.position = "src/index.js 78:81",
                          Error(e)
                      }
                  }, !1)}else{
                    e.attachEvent("resize", function() {
                      try {
                          clearTimeout(i),
                          i = setTimeout(r, 300)
                      } catch (e) {
                          throw e.position = "src/index.js 78:81",
                          Error(e)
                      }
                  }, !1)
                  }
                  if(document.addEventListener){
                  e.addEventListener("pageshow", function(e) {
                      try {
                          e.persisted && (clearTimeout(i),
                          i = setTimeout(r, 300))
                      } catch (e) {
                          throw e.position = "src/index.js 82:87",
                          Error(e)
                      }
                  }, !1)}else{
                    e.attachEvent("pageshow", function(e) {
                      try {
                          e.persisted && (clearTimeout(i),
                          i = setTimeout(r, 300))
                      } catch (e) {
                          throw e.position = "src/index.js 82:87",
                          Error(e)
                      }
                  }, !1)
                  }
                  if(document.addEventListener){
                  "complete" === n.readyState ? n.body.style.fontSize = 12 * s + "px" : n.addEventListener("DOMContentLoaded", function(e) {
                      try {
                          n.body.style.fontSize = 12 * s + "px"
                      } catch (e) {
                          throw e.position = "src/index.js 92:94",
                          Error(e)
                      }
                  }, !1)}else{
                    "complete" === n.readyState ? n.body.style.fontSize = 12 * s + "px" : n.attachEvent("DOMContentLoaded", function(e) {
                      try {
                          n.body.style.fontSize = 12 * s + "px"
                      } catch (e) {
                          throw e.position = "src/index.js 92:94",
                          Error(e)
                      }
                  }, !1)
                  }
                  r(),
                  p.dpr = e.dpr = s,
                  p.refreshRem = r,
                  p.rem2px = function(e) {
                      try {
                          var t = parseFloat(e) * this.rem;
                          return "string" == typeof e && e.match(/rem$/) && (t += "px"),
                          t
                      } catch (r) {
                          throw r.position = "src/index.js 102:108",
                          Error(r)
                      }
                  }
                  ,
                  p.px2rem = function(e) {
                      try {
                          var t = parseFloat(e) / this.rem;
                          return "string" == typeof e && e.match(/px$/) && (t += "rem"),
                          t
                      } catch (r) {
                          throw r.position = "src/index.js 109:115",
                          Error(r)
                      }
                  }
              } catch (b) {
              }
          }(window, window.lib || (window.lib = {}))
      }
  })
});
//# sourceMappingURL=lib-flexible.js.map

