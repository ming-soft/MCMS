$(function() {
    function currentposition() {
        var Turl = window.location.href;
        function eqNav(e) {
            $(".nav li").removeClass("on");
            $(".nav li").eq(e).addClass("on");
            $(".app-nav li").removeClass("on");
            $(".app-nav li").eq(e).addClass("on");
        }
        if(Turl.indexOf("/szf/")!="-1"){
            eqNav(1)
        }
        else if(Turl.indexOf("/zfxxgk/")!="-1"){
            eqNav(2)
        }
        else if(Turl.indexOf("/jdhy/")!="-1"){
            eqNav(3)
        }
        else if(Turl.indexOf("/hdjl/")!="-1"){
            eqNav(5)
        }
        else if(Turl.indexOf("/xfzs/")!="-1"){
            eqNav(6)
        }
    }
    currentposition();

    jQuery("#nav").slide({ type: "menu", titCell: ".nLi", delayTime: 0, triggerTime: 0, returnDefault: true });
    jQuery(".app-nav").slide({ type: "menu", titCell: "li", delayTime: 0, triggerTime: 0, returnDefault: true });
    jQuery(".tab_box").slide({ titCell: ".hd li", mainCell: ".bd", targetCell: ".more", delayTime: 0, triggerTime: 0 });
    /* 控制左右按钮显示 */
    $(".slideBox").hover(function() { jQuery(this).find(".prev,.next").stop(true, true).fadeTo("show", 1) }, function() { jQuery(this).find(".prev,.next").fadeOut() });
    jQuery(".slideBox").slide({ titCell: ".hd ul", mainCell: ".bd ul", autoPlay: true, effect: "fold", interTime: 5000, autoPage: true });


    if (navigator.appVersion.search(/MSIE 7/i) != -1) {
        alert("您当前的浏览器版本过低，不能友好的兼容H5，建议升级浏览器!")
    }

    $(".app-search-btn").click(function () {
        $(".app-search").stop(true,true).slideToggle();
        $(this).toggleClass("on");
    })

});

function BMsearch(cla,tit){
    if ($(cla).val()===""){
        if(tit!==undefined){
            layer.msg(tit, {icon: 2});
        }else {
            layer.msg('请输入您想要搜索的内容!', {icon: 2});
        }
        $(cla).focus();
        return false;
    }
}

$.fn.Horizontal = function(cla,clb) {
    $(this).each(function () {
        var box = $(this),
            boxContainer = box.find(cla),
            mumber = box.find(clb),
            mumberWidth = mumber.outerWidth(true),
            length = mumber.length,
            boxContainerWidth = mumberWidth*length;
        boxContainer.css('width',boxContainerWidth);

        boxContainer.on('mousedown',function(e){
            var posX = e.screenX;//鼠标点击时候的位置
            var currentScroll = box.scrollLeft(); //当前的scrollLeft值
            box.on('mousemove',function(e){
                var posL = e.clientX,//滚动后鼠标的位置
                    moveX = posL - posX;//鼠标拖动距离
                moveX = currentScroll + -moveX;
                box.scrollLeft(moveX);
                //清空事件
                return false;
            });
            //清空事件
            box.on('mouseup',function(){
                $(this).unbind();
            })
        })
    })
};

$.fn.Drag = function() {
    var cla = $(this);
    var dragging = false;
    var iX, iY;
    var claW = $(document).width()-cla.width();
    var claH = $(document).height()-cla.height();
    $(window).scroll(function () {
        claH = $(document).height()-cla.height();
    });
    cla.mousedown(function(e) {
        dragging = true;
        iX = e.clientX - this.offsetLeft;
        iY = e.clientY - this.offsetTop;
        this.setCapture && this.setCapture();
        return false;
    });
    document.onmousemove = function(e) {
        if (dragging) {
            var e = e || window.event;
            var oX = e.clientX - iX;
            var oY = e.clientY - iY;
            if(oX>=claW){oX=claW;}
            if(oX<=0){oX=0;}
            if(oY>=claH){oY=claH;}
            if(oY<=0){oY=0;}
            cla.css({
                "left": oX + "px",
                "top": oY + "px"
            });
            return false;
        }
    };
    $(document).mouseup(function(e) {
        dragging = false;
        //cla[0].releaseCapture();
        e.cancelBubble = true;
    });
};


