
// 我的评论与回复我的两个按钮的tab切换
$(function(){

    var link = window.location.href;
    var siteId;
    // 站点siteId（其实也是必传）
    if(link.indexOf("siteId")>0){
        var firSiteId = link.split("siteId=");
        var twoSiteId = firSiteId[1].split("&");
        siteId = twoSiteId[0];
    }
    if(link.indexOf("siteid")>0){
        var firSiteId = link.split("siteid=");
        var twoSiteId = firSiteId[1].split("&");
        siteId = twoSiteId[0];
    }
    var EsiteId = siteId?siteId:639;
    $(".nav-item2 a").attr('href','./index.html?siteId='+EsiteId);
    $(".nav-item3 a").attr('href','./qtmh.html?siteId='+EsiteId);
    $(".nav-item4 a").attr('href','./tablist.html?siteId='+EsiteId);
    $(".nav-item5 a").attr('href','./wzxx.html?siteId='+EsiteId);
    $(".nav-item6 a").attr('href','./ysqgk.html?siteId='+EsiteId);
    $(".nav-item7 a").attr('href','./zxdc.html?siteId='+EsiteId);





  $(".cment-about-mebtn a").click(function(){
    var index = $(this).parent().children("a").index($(this));
    $(this).addClass('cur').siblings().removeClass('cur');
    $(this).parent().siblings(".vvmi-part-bg").find(".vvmi-cbkmy-items").eq(index).show().siblings().hide();
  })
})



// 站内搜索
jQuery(function(){
  var $label=jQuery('.nx-sear-sel .nx-tag'),
    $optionItem=jQuery('.nx-sel-item li');
    $label.click(function(){
        $(this).siblings(".nx-sel-item").slideToggle();
    })
  $optionItem.on('click',function(){
    var text=$(this).children().text();
    $(this).parent().siblings('p.nx-tag').text(text)
    $(this).parent().slideUp();
  });
});
// $(document).ready(function(){
//     var forget_box_h = $(window).height();
//     // $(".forget-pwd-bg").css({'height':forget_box_h,'display':'none'});
//     $(window).resize(function(){
//         var forget_box_h = $(window).height();
//         $(".forget-pwd-bg").css({'height':forget_box_h});
//     })
//     $(".forget-pwd-bg").click(function(){
//         hideFun();
//     });
//     function hideFun(){
//         $(".forget-pwd-bg").hide();
//         $(".forget-pwd-box").hide();
//     };
// })










