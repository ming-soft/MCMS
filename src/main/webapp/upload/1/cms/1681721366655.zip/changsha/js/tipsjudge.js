$(function () {



    //init();

    var currentIndex = -1;

    $("#sug-box").on("click", "li", function () {
        $("#search_input").on("change", function () {
            submitForm();
        });
        var value = $(this).text();
        $("#search_input").val(value);
        $("#sug-box").hide();
        $("#search_input").trigger("change");
        $("#search_input").off("change");
    })

    var changeFocus = function (t) {
        var val = t.text();
        $('.changvalue').val(val);
        $('.tips_box li').removeClass('current');
        t.addClass('current');
    };




    $(function(){
        if(navigator.userAgent.match(/mobile/i)) {
            var jqXHQ;
            $(".searchbox").on('input','input',function(event){
                event.stopPropagation();
                var key = event.keyCode;
                if(key == 38){
                    movethis(true);
                }else if(key == 40){
                    movethis(false);
                }else if(key == 13){
                    $("#sug-box").hide();
                    $("li.current").trigger("click");
                }else {
                    event.stopPropagation();
                    $("#sug-box").data("currentIndex", -1);
                    var q = $("#search_input").val();
                    var t = "hunan";
                    var size = 10;
                    if (jqXHQ) {
                        jqXHQ.abort();
                    }
                    jqXHQ = $.ajax({
                        url: baseAction + "/sug?t=" + t + "&q=" + encodeURI(q) + "&n=" + size,
                        type: "GET",
                        // success: function (data) {
                        //     if(data.code == 1){
                        //         var sugWordList = data.sugWordList;
                        //         var sugTitleList = data.sugTitleList;
                        //         var display = false;
                        //         var sugBoxHtml = "";
                        //         var size = 0;
                        //         if(sugWordList){
                        //             var phase = '<ul class="phrase">';
                        //             $.each(sugWordList, function (i, item) {
                        //                 phase += '<li><p>' + item + '</p></li>';
                        //                 size += 1;
                        //             });
                        //             phase += '</ul>';
                        //             sugBoxHtml += phase;
                        //             display = true;
                        //         }
                        //         if(display){
                        //             sugBoxHtml += '<p class="tips_line"></p>';
                        //         }
                        //         if(sugTitleList){
                        //             var title = '<ul class="long_title">';
                        //             $.each(sugTitleList, function (i, item) {
                        //                 title += '<li><p><a href="' + item.url + '" target="_blank">' + item.title + '</a></p></li>';
                        //                 size += 1;
                        //             });
                        //             title += '</ul>';
                        //             sugBoxHtml += title;
                        //             display = true;
                        //         }
                        //         if(display){
                        //             $("#sug-box").html(sugBoxHtml).show();
                        //             $("#sug-box").data("size",size);
                        //             $("#sug-box").show();

                        //         }else {
                        //             $("#sug-box").html("").hide();
                        //         }
                        //     }else {
                        //         $("#sug-box").html("").hide();

                        //     }
                        // }
                    }).done(function (data) {
                        if(data.code == 1){
                            var sugWordList = data.sugWordList;
                            var sugTitleList = data.sugTitleList;
                            var display = false;
                            var sugBoxHtml = "";
                            var size = 0;
                            if(sugWordList){
                                var phase = '<ul class="phrase">';
                                $.each(sugWordList, function (i, item) {
                                    phase += '<li><p>' + item + '</p></li>';
                                    size += 1;
                                });
                                phase += '</ul>';
                                sugBoxHtml += phase;
                                display = true;
                            }
                            if(display){
                                sugBoxHtml += '<p class="tips_line"></p>';
                            }
                            if(sugTitleList){
                                var title = '<ul class="long_title">';
                                $.each(sugTitleList, function (i, item) {
                                    title += '<li><p><a href="' + item.url + '" target="_blank">' + item.title + '</a></p></li>';
                                    size += 1;
                                });
                                title += '</ul>';
                                sugBoxHtml += title;
                                display = true;
                            }
                            if(display){
                                $("#sug-box").html(sugBoxHtml).show();
                                $("#sug-box").data("size",size);
                                $("#sug-box").show();

                            }else {
                                $("#sug-box").html("").hide();
                            }
                        }else {
                            $("#sug-box").html("").hide();

                        }
                    });
                }
            })
        }else{

            $("#search_input").on("keyup" ,function (event) {
                event.stopPropagation();
                var key = event.keyCode;
                if(key == 38){
                    movethis(true);
                }else if(key == 40){
                    movethis(false);
                }else if(key == 13){
                    $("#sug-box").hide();
                    $("li.current").trigger("click");
                }else {
                    event.stopPropagation();
                    $("#sug-box").data("currentIndex", -1);
                    var q = $("#search_input").val();
                    var t = "hunan";
                    var size = 10;
                    $.ajax({
                        url: baseAction + "/sug?t=" + t + "&q=" + encodeURI(q) + "&n=" + size,
                        type: "GET",
                        success: function (data) {
                            if(data.code == 1){
                                var sugWordList = data.sugWordList;
                                var sugTitleList = data.sugTitleList;
                                var display = false;
                                var sugBoxHtml = "";
                                var size = 0;
                                if(sugWordList){
                                    var phase = '<ul class="phrase">';
                                    $.each(sugWordList, function (i, item) {
                                        phase += '<li><p>' + item + '</p></li>';
                                        size += 1;
                                    });
                                    phase += '</ul>';
                                    sugBoxHtml += phase;
                                    display = true;
                                }
                                if(display){
                                    sugBoxHtml += '<p class="tips_line"></p>';
                                }
                                if(sugTitleList){
                                    var title = '<ul class="long_title">';
                                    $.each(sugTitleList, function (i, item) {
                                        title += '<li><p><a href="' + item.url + '" target="_blank">' + item.title + '</a></p></li>';
                                        size += 1;
                                    });
                                    title += '</ul>';
                                    sugBoxHtml += title;
                                    display = true;
                                }
                                if(display){
                                    $("#sug-box").html(sugBoxHtml).show();
                                    $("#sug-box").data("size",size);
                                    $("#sug-box").show();

                                }else {
                                    $("#sug-box").html("").hide();
                                }
                            }else {
                                $("#sug-box").html("").hide();

                            }
                        }
                    });
                }

            });

        }
       });





    function movethis(up){
        var size = $("#sug-box").data("size");
        var currentIndex = $("#sug-box").data("currentIndex");
        currentIndex = currentIndex + (up ? -1 : 1);
        if(currentIndex >= size){
            currentIndex = 0;
        }else if(currentIndex < 0){
            currentIndex = size -1;
        }
        $("#sug-box li").removeClass("current");
        $($("#sug-box li")[currentIndex]).addClass("current");
        var text = $($("#sug-box li")[currentIndex]).text();
        $("#search_input").val(text);
        $("#sug-box").data("currentIndex", currentIndex);
    }

    $(document).click(function (event) {
        var tar = $("#search_input");
        if(!tar.is(event.target) && tar.has(event.target).length === 0){
            $("#sug-box").hide();
        }
    });

});
