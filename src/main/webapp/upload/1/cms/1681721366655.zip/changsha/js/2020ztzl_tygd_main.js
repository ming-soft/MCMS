/**
 * Created by 方益 on 2020/03/02.
 */
function tygdHtml(arrTime) {
    $(function() {
        var str = "<div  id='gd' style='cursor: not-allowed;position: fixed; z-index: 999; right: 50px; top: 90px; text-align: center;-webkit-transform: rotate(30deg);  -moz-transform: rotate(30deg);  transform: rotate(30deg);'>";
        str += "<div id='gd-time' style='color: #ff0000; font-size: 17px; margin-bottom: 5px;'>归档时间：" + arrTime + "</div>";
        str += "    <div style='width: 180px; height: 60px; border: 5px solid #ff0000; line-height: 60px; color: #ff0000; font-size: 36px; font-weight: bold; border-radius: 10px;'>已归档</div>";
        str += "</div>";
        $("body").append(str)
    })
}
function tygdApp(arrUrl,arrTime){
    var current = window.location.href;
    //console.log(gdurl);
    if(current.indexOf(arrUrl)!="-1"){
        tygdHtml(arrTime)
    }
}
$(function () {
    var arrUrl = [
        
        "http://www.changsha.gov.cn/szf/ztzl/hbdc2021/",
        
        "http://www.changsha.gov.cn/szf/ztzl/2020zwgkgzydzl/",
        
        "http://www.changsha.gov.cn/szf/ztzl/lh/",
        
        "http://www.changsha.gov.cn/szf/ztzl/zxgzlsxc/",
        
        "http://www.changsha.gov.cn/szf/ztzl/hbdc2020",
        
        "http://www.changsha.gov.cn/szf/ztzl/2018gzzl/",
        
        "http://www.changsha.gov.cn/szf/ztzl/wzgznb/",
        
        "http://www.changsha.gov.cn/szf/ztzl/2020zslh/",
        
        "http://www.changsha.gov.cn/szf/ztzl/gzyd2018",
        
    ];
    var arrTime = [
        
        "2021-05-31",
        
        "2021-03-31",
        
        "2021-03-05",
        
        "2021-03-05",
        
        "2020-11-15",
        
        "2020-04-17",
        
        "2018-04-10",
        
        "2020-04-17",
        
        "2020-01-31",
        
    ];
    for(var i = 0; i < arrUrl.length; i++) {
        //console.log(arrUrl[i]);
        //console.log(arrTime[i]);
        tygdApp(arrUrl[i],arrTime[i])
    }
});