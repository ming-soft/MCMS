(function ($) {

    var keyword = [];
    var historylist = [];
    /**
     * 查询cookie
     * @param c_name
     * @returns
     */
    getCookie = function (c_name) {
        if (document.cookie.length > 0) {
            c_start = document.cookie.indexOf(c_name + "=");
            if (c_start != -1) {
                c_start = c_start + c_name.length + 1;
                c_end = document.cookie.indexOf(";", c_start);
                if (c_end == -1)
                    c_end = document.cookie.length;
                return unescape(document.cookie.substring(c_start, c_end));
            }
        }
        return "";
    }

    function init() {
        getCookie();
        // setCookie("Cookie1", keyword,start, "/"); //24小时过期 //24小时过期
        historylist = getCookie('Cookie1').split(',');
        keyword = historylist;
        $(".history-list").find("li").remove();
        for (var x in historylist) {
            // console.log(x);
            if(historylist[x].length == 0){
            	continue;
            }
            $('.history-list').append('<li><a href="/hunan/s.htm?cs=news&q=' + historylist[x] + '">' + historylist[x] + '</a></li>');
        }

    }
    init();

    /**
     * 添加/修改cookie
     * @param c_name
     * @param value
     * @param expireTimes
     */
    setCookie = function (c_name, value, expireTimes, path) {
        // document.cookie="token=00001;path=/";
        var exdate = new Date();
        // console.log(c_name + "=" + value + ((expireTimes == null) ? "" : ";expires=" + exdate.toGMTString()) + "; path=" + path)
        exdate.setTime(expireTimes);
        document.cookie = c_name + "=" + value + ((expireTimes == null) ? "" : ";expires=" + exdate.toGMTString()) + ";path=" + path;

        // console.log(document.cookie.length)

    }

    pushKeyword = function(word){
    	var temKeyword = [];
    	temKeyword.push(word);
    	var index = 9;
    	if(keyword.length < index){
    		index = keyword.length;
    	}
    	for(var i = 0; i < index; i++){
    		if(keyword[i] == word){
    			continue;
    		}
    		temKeyword.push(keyword[i]);
    	}
    	keyword = temKeyword;
    }

    function clearAllCookie() {
        var date = new Date();
        date.setTime(date.getTime() - 10000);
        var keys = document.cookie.match(/[^ =;]+(?=\=)/g);
        //console.log("需要删除的cookie名字：" + keys);
        if (keys) {
            for (var i = keys.length; i--;)
                document.cookie = keys[i] + "=; expire=" + date.toGMTString() + "; path=/";
        }
    }

    $(".hotword a").on('click', function () {
        var start = new Date(new Date(new Date().toLocaleDateString()).getTime() + 24 * 60 * 60 * 1000 - 1);
        // alert($(this).data('text'));
        pushKeyword($(this).text());
        // console.log(keyword);
        setCookie("Cookie1", keyword, start, "/"); //24小时过期 //24小时过期
        historylist = getCookie('Cookie1').split(',');
        // console.log(historylist);
        $(".history-list").find("li").remove();
        for (var x in historylist) {
            // console.log(x, '.llllllll');
            if(historylist[x].length == 0){
            	continue;
            }
            $('.history-list').append('<li><a href="/hunan/s.htm?cs=news&q=' + historylist[x] + '">' + historylist[x] + '</a></li>');
        }
    })

    $('#search_input').bind('keyup', function (event) {
        /*if (event.keyCode == "13") {
            $('.search-btn').click();
        }*/
        /*if (event.keyCode == "13") {
            //回车执行查询
            $(':input[name="timetype"]').val('');
            var start = new Date(new Date(new Date().toLocaleDateString()).getTime() + 24 * 60 * 60 * 1000 - 1);
            pushKeyword($('.searchbox').find('input').val());
            // console.log(keyword)
            setCookie("Cookie1", keyword, start, "/"); //24小时过期 //24小时过期

            historylist = getCookie('Cookie1').split(',');
            $(".history-list").find("li").remove();
            for (var x in historylist) {
            	if(historylist[x].length == 0){
                	continue;
                }
                $('.history-list').append('<li><a href="/hunan/s.htm?cs=news&q=' + x + '">' + x + '</a></li>');
            }
        }*/
    });
    // setCookie("Cookie1", JSON.stringify(keyword),start, "/"); //24小时过期 //24小时过期


    $('#mydatepicker').dcalendarpicker(); //初始化日期选择器
    $('#mydatepicker2').dcalendarpicker(); //初始化日期选择器

    // 时间不限下拉框
    // $('.xiala p').on('click',function(){
    //   if($('.choosedate').css('display') == 'none'){
    //     $('.choosedate').css('display','block');
    //   }else{
    //     $('.choosedate').css('display','none');
    //   }
    // })

    // 高级搜索
    $('.senior').on('click', function () {
        if ($('.mencon').css('display') == 'none') {
            $('.mencon').css('display', 'block');
        } else {
            $('.mencon').css('display', 'none');
        }
        if ($('.pop_box').css('display') == 'none') {
            $('.pop_box').css('display', 'block');
        } else {
            $('.pop_box').css('display', 'none');
        }

    })
    $('.closed-btn').on('click', function () {
        $('.mencon').css('display', 'none');
        $('.pop_box').css('display', 'none');
    })


    // 清除历史
    $('.clear').on('click', function () {
        $(".history-list").find("li").remove();
        $('.clear').css('display', 'block');
        keyword = [];
        historylist = [];
        clearAllCookie();
    });

    $('.classify').find('p').on('click', function () {
        $('.classify').find('p').removeClass('active');
        $(this).attr('class', 'active');
    })

    // $('.shouqi').on('click',function(){
    //   $(this).css('display','none');
    //   $('.zhankai').css('display','block');
    // })
    // $('.zhankai').on('click',function(){
    //   $(this).css('display','none');
    //   $('.shouqi').css('display','block');
    // })

    // 删除搜索词
    $('.search-btn2').on('click', function () {
        $("#search_input").val('');
    })
    $('.search-btn2').on('click', function () {
        if ($('.search-btn2').css('display') == 'none') {
            $('.search-btn2').css('display', 'block');
        } else {
            $('.search-btn2').css('display', 'none');
        }
    })


    //   $('.myselfbtn').on('click',function(){
    //     if($('.myself').css('display') == 'none'){
    //       $('.myself').css('display','block');
    //     }else{
    //       $('.myself').css('display','none');
    //     }
    //  })

    //  $('.shouqi').on('click',function(){
    //   $(".r-leader").eq(1).css('display','none');
    // })
    // $('.zhankai').on('click',function(){
    //   $(".r-leader").eq(1).css('display','block');
    // })

    // 右侧点击展开

    // $('.r-com-title span a').on('click', function(){
    //   var selectDiv = $(this).parents('.related');
    //   if($(this).parent().hasClass('zhankai')) {
    //       if(selectDiv.find('ul').length>1) {
    //           selectDiv.find('ul').show();

    //       }
    //       else {
    //         selectDiv.find('ul:gt(0)').hide();
    //       }
    //   }
    //   else{
    //     selectDiv.find('ul:gt(0)').hide();
    //   }
    //   $(this).parent().hide();
    //   $(this).parent().siblings().show();
    // });




    // $('.choosedate ul li').on('click',function(){
    //   console.log($(this).text())
    //   $(this).addClass('li-cur');
    //   $(this).siblings().removeClass('li-cur');
    //   $('.chstime-con').text($(this).text());
    // })

    // $('.myself button').on('click',function(){
    //   $('.choosedate').css('display','none');
    // })


    // 蒙层居中处理e
    $('#search_input').on('input propertychange', function () {
        var result = $('#search_input').val();
        if (result && result != '') {
            $('.search-btn2').css('display', 'block');
        } else {
            $('.search-btn2').css('display', 'none');
        }
    });




})(jQuery);
$("#search_input").on('keydown', function (e) {
});
