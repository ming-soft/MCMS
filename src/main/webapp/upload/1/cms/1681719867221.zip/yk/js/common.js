// JavaScript Document
//不要让自己无限的幻想与创造力埋没在沉默中，不要让别人的创新死在自己的无知与狭义的看法下。--青格勒(cenggel)
window.onload = function(){
	//IE7分页去阴影
	$("#AspNetPager1 a").removeAttr("disabled");
	//返回顶部
	$(".to_top").click(function () {$('html,body').animate({ scrollTop: '0px' }, 500); return false;});
};
//===================分割线===================
$(function(){
//表单选择 当获取光标时会把原先的value清除，离开时如果没有改变会回复原先的value
	$(".inputtext").focus(function () {
			if ($(this).val() == "" || $(this).val() == this.defaultValue) {
				$(this).attr('cont',$(this).val())
				$(this).attr("value", "");
			}
	});
	$(".inputtext").blur(function () {
		if ($(this).attr("date") == undefined) {
			if ($(this).val() == "" || $(this).val() == $(this).attr("cont")) {
				$(this).attr("value", $(this).attr("cont"));
			}
		}
	});
});
//===================分割线===================
    //放大放小
    num = $("#contentText").attr("size");
    function fangda(){
        num++;
        if(num > 18){
            num = 18;
        }
        $("#contentText").css({"font-size":num+'px',"line-height":"1.8em"});
        $("#contentText").find("*").css({"font-size":num+'px',"line-height":"1.8em"});
    }
    function suoxiao(){
        num--;
        if(num < 12){
            num = 12;
        }
        $("#contentText").css({"font-size":num+'px',"line-height":"1.8em"});
        $("#contentText").find("*").css({"font-size":num+'px',"line-height":"1.8em"});
    }


//===================分割线===================
function doZoom(size) {
//大中小
	var zoom = document.all ? document.all['Zoom'] : document.getElementById('Zoom');
	$("#Zoom").find("*").css({ "font-size": size + "px" });
	$("#Zoom").css({ "font-size": size + "px" });
}
//===================分割线===================
function SetHome(url){
//设为首页
  if (document.all) {
	  document.body.style.behavior='url(#default#homepage)';
		 document.body.setHomePage(url);
  }else{
	  alert("您好，您的浏览器不支持自动设置页面为首页功能，请您手动在浏览器里设置该页面为首页！");
  }};
function AddFavorite(sURL, sTitle) {
//加入收藏
  sURL = encodeURI(sURL);
  try {
	  window.external.addFavorite(sURL, sTitle);
  } catch (e) {
	  try {
		  window.sidebar.addPanel(sTitle, sURL, "");
	  } catch (e) {
		  alert("加入收藏失败，请使用Ctrl+D进行添加，或手动在浏览器里进行设置。");}}};
//===================分割线===================
//控制ul的li的margin的JQ选项
  //cg_margin_rightnone系列为margin-right:0px;
  //cg_margin_topnone系列为margin-top:0px;
$(document).ready(function(e) {
$(".cg_margin_rightno12 li").each(function(index, element) {if(($(this).index()+1)%12==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_rightno11 li").each(function(index, element) {if(($(this).index()+1)%11==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_rightno10 li").each(function(index, element) {if(($(this).index()+1)%10==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_rightno9 li").each(function(index, element) {if(($(this).index()+1)%9==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_rightno8 li").each(function(index, element) {if(($(this).index()+1)%8==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_rightno7 li").each(function(index, element) {if(($(this).index()+1)%7==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_rightno6 li").each(function(index, element) {if(($(this).index()+1)%6==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_rightno5 li").each(function(index, element) {if(($(this).index()+1)%5==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_rightno4 li").each(function(index, element) {if(($(this).index()+1)%4==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_rightno3 li").each(function(index, element) {if(($(this).index()+1)%3==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_rightno2 li").each(function(index, element) {if(($(this).index()+1)%2==0){$(this).addClass('cg_margin_rightno');}});
$(".cg_margin_topno12 li:lt(12)").addClass('cg_margin_topno');
$(".cg_margin_topno11 li:lt(11)").addClass('cg_margin_topno');
$(".cg_margin_topno10 li:lt(10)").addClass('cg_margin_topno');
$(".cg_margin_topno9 li:lt(9)").addClass('cg_margin_topno');
$(".cg_margin_topno8 li:lt(8)").addClass('cg_margin_topno');
$(".cg_margin_topno7 li:lt(7)").addClass('cg_margin_topno');
$(".cg_margin_topno6 li:lt(6)").addClass('cg_margin_topno');
$(".cg_margin_topno5 li:lt(5)").addClass('cg_margin_topno');
$(".cg_margin_topno4 li:lt(4)").addClass('cg_margin_topno');
$(".cg_margin_topno3 li:lt(3)").addClass('cg_margin_topno');
$(".cg_margin_topno2 li:lt(2)").addClass('cg_margin_topno');
//公用hover显示隐藏JQ
    //h1 标题滚动
    (function() {
        if ($('.ql_h_animate').length > 0) {
            var hbtr_top = $('.ql_h_animate').offset().top - 100;
            var timerx = setTimeout(function(){
                $('html,body').animate({ scrollTop: hbtr_top+'px' }, 800); return false;
            },400);
            $(window).on('mousewheel DOMMouseScroll', function() {
                clearTimeout(timerx);
                $('html, body').stop(true);
            });
        }
    })();
    //
});